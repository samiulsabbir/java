package bankinterestcalculator;


public class BankInterestCalculator 
{
    public void show(InterestCalculator inc)
    {
        inc.writeInterest();
    }
  
    public static void main(String[] args) 
    {
      BankInterestCalculator xyz = new BankInterestCalculator();
      xyz.show(new CarInterest());
      xyz.show(new HomeInterest());
      xyz.show(new PersonalLoanInterest());
    }
    
}
