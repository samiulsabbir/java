
package bankinterestcalculator;


public class PersonalLoanInterest implements InterestCalculator
{
    public void writeInterest()
    {
        System.out.println("Personal Loan Interest is : 0.34%");
    }
}
