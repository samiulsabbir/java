
package bankinterestcalculator;


public class CarInterest implements InterestCalculator
{
    public void writeInterest()
    {
        System.out.println("Car Interest Is: 7%");
    }
    
}
