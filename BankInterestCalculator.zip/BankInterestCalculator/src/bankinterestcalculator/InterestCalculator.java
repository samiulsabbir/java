
package bankinterestcalculator;


public interface InterestCalculator 
{
    public void writeInterest();
}
