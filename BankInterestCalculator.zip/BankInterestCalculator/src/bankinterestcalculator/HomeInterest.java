package bankinterestcalculator;


public class HomeInterest implements InterestCalculator
{
    public void writeInterest()
    {
          System.out.println("Home interest Is: 0.5%");
    }
}
